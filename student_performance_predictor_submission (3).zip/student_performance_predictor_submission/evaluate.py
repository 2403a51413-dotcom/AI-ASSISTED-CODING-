import pandas as pd
import pickle
from sklearn.metrics import r2_score, mean_absolute_error

# Load model
with open("student_model.pkl", "rb") as f:
    model = pickle.load(f)

# Load test dataset
df = pd.read_csv("test_data_25percent.csv")

X_test = df[["study_hours", "attendance", "previous_score"]]
y_test = df["final_score"]

# Predictions
y_pred = model.predict(X_test)

# CAP predictions to 0–100
y_pred = [max(0, min(100, p)) for p in y_pred]

# Convert to DataFrame for display
results = pd.DataFrame({
    "Study Hours": X_test["study_hours"],
    "Attendance": X_test["attendance"],
    "Previous Score": X_test["previous_score"],
    "Actual Final Score": y_test,
    "Predicted Final Score": y_pred
})

print(results.head(20))

# Accuracy metrics
r2 = r2_score(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
success_rate = 100 - mae

print("\nModel Evaluation")
print("---------------------")
print(f"R² Score: {r2:.3f}")
print(f"Mean Absolute Error: {mae:.2f}")
print(f"Approx Success Rate: {success_rate:.2f}%")
