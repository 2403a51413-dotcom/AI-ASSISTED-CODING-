import streamlit as st
import pickle
import numpy as np

# Load trained model
with open("student_model.pkl", "rb") as f:
    model = pickle.load(f)

st.title("🎓 Student Performance Predictor")
st.write("Enter your details below to predict the final exam score.")

# Input fields (VALIDATED)
study_hours = st.number_input(
    "Study Hours (0–24)",
    min_value=0.0,
    max_value=24.0,
    step=0.1
)

attendance = st.number_input(
    "Attendance (%) (0–100)",
    min_value=0.0,
    max_value=100.0,
    step=0.1
)

previous_score = st.number_input(
    "Previous Test Score (0–100)",
    min_value=0.0,
    max_value=100.0,
    step=0.1
)

if st.button("Predict Final Score"):
    # Prepare input
    input_data = np.array([[study_hours, attendance, previous_score]])

    # Predict
    predicted_score = model.predict(input_data)[0]

    # CAP FINAL SCORE
    predicted_score = max(0, min(100, predicted_score))

    st.success(f"📘 Predicted Final Score: **{predicted_score:.2f} / 100**")
