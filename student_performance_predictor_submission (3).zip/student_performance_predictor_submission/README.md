# Student Performance Predictor

## 📘 Overview
This project predicts students' final exam performance based on:
- Study hours
- Attendance percentage
- Previous test scores

## 🧠 Technology Used
- Python
- Pandas, NumPy
- Scikit-learn
- Streamlit

## ⚙️ How to Run
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
