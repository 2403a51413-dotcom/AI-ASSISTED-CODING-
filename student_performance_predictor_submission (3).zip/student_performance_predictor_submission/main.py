import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import pickle

# Load dataset
df = pd.read_csv("students.csv")

# Prepare features and target
X = df[["study_hours", "attendance", "previous_score"]]
y = df["final_score"]

# Split 75% train / 25% test
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict test data
y_pred = model.predict(X_test)

# CAP PREDICTIONS to 0–100
y_pred = [max(0, min(100, p)) for p in y_pred]

# Evaluate
mse = mean_squared_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print("Training complete!")
print("MSE:", mse)
print("R² Score:", r2)

# Save trained model
with open("student_model.pkl", "wb") as f:
    pickle.dump(model, f)
